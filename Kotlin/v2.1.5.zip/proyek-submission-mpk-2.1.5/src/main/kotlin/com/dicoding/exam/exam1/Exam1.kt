package com.dicoding.exam.exam1

// TODO 1
fun isEvenNumber(number: Int): Boolean {
    return false
}

// TODO 2
fun moreThanFive(number: Int): Boolean {
    return false
}

// TODO 3
fun result(number: Int): Int {
    return 0
}