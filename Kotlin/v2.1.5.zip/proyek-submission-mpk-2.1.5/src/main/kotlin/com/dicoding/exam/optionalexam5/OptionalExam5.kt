package com.dicoding.exam.optionalexam5

// TODO
fun concatString(string1: String, string2: String): String {
    return ""
}
