package com.dicoding.exam.exam5

// TODO 1
fun sum(valueA: Int, valueB: Int): Int {
    return 0
}

// TODO 2
fun multiple(valueA: Int, valueB: Int): Int {
    return 0
}
