package com.dicoding.exam.exam2

// TODO 1
fun calculate(valueA: Int, valueB: Int, valueC: Int?): Int {
    return 0
}

// TODO 2
fun result(result: Int): String {
    return ""
}