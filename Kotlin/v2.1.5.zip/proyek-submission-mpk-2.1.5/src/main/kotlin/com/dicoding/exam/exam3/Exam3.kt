package com.dicoding.exam.exam3

// TODO
fun vehicle() = Any()