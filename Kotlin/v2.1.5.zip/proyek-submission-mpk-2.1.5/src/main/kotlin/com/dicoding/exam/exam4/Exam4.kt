package com.dicoding.exam.exam4

// TODO
open class Car() {
    open fun getCarInfo(): String
}

// TODO
class ElectricCar() : Car() {
    override fun getCarInfo(): String
}