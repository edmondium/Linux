package com.dicoding.exam.optionalexam4

// TODO
fun getMiddleCharacters(string: String): String {
    return ""
}