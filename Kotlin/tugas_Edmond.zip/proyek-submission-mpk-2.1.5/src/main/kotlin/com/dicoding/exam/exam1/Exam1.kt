package com.dicoding.exam.exam1

// TODO 1
fun isEvenNumber(number: Int): Boolean {
    return number % 2 == 0
    // return false
}

// TODO 2
fun moreThanFive(number: Int): Boolean {
    return number > 5
    // return false
}

// TODO 3
fun result(number: Int): Int {
    return number * (number + 10)
    // return 0
}
