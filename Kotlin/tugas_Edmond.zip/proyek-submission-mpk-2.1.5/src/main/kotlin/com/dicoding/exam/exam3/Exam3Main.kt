package com.dicoding.exam.exam3

private fun main() {
    println(
        """
        My Map Result:
        ${vehicle()}
        """.trimIndent()
    )
}
